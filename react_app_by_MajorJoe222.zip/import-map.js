// This script defines the import map for your browser to resolve module specifiers.
// It allows you to import React and ReactDOM directly from CDN.
document.head.append(
  Object.assign(document.createElement("script"), {
    type: "importmap",
    textContent: JSON.stringify({
      imports: {
        "react": "https://esm.sh/react@18.2.0?dev",
        "react-dom/client": "https://esm.sh/react-dom@18.2.0/client?dev",
        "react/jsx-dev-runtime": "https://esm.sh/react@18.2.0/jsx-dev-runtime?dev",
        "lucide-react": "https://esm.sh/lucide-react@0.323.0?dev"
      }
    })
  })
);