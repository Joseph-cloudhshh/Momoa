import { Fragment, jsxDEV } from "react/jsx-dev-runtime";
import React, { useState, useEffect } from "react";
import { Header } from "./components/layout/Header.jsx";
import { HeroSection } from "./components/sections/HeroSection.jsx";
import { ShopSection } from "./components/sections/ShopSection.jsx";
import { ShoppingCartSidebar } from "./components/layout/ShoppingCartSidebar.jsx";
import { NewsletterSection } from "./components/sections/NewsletterSection.jsx";
import { Footer } from "./components/layout/Footer.jsx";
import { MembershipSection } from "./components/sections/MembershipSection.jsx";
import { TrainingSection } from "./components/sections/TrainingSection.jsx";
import { AboutSection } from "./components/sections/AboutSection.jsx";
import { LoginPage } from "./components/sections/LoginPage.jsx";
import { FeaturedSections } from "./components/sections/FeaturedSections.jsx";
import { ContactSection } from "./components/sections/ContactSection.jsx";
function App() {
  const [cartItems, setCartItems] = useState([]);
  const [showCart, setShowCart] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [currentPage, setCurrentPage] = useState("home");
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Escape") {
        setShowCart(false);
        setShowMobileMenu(false);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);
  const products = [
    { id: 1, name: "Aquaman Trident Replica", price: 299, category: "collectibles", description: "Official movie replica trident from Aquaman", image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/c14c7bee-e511-4f05-add9-fd235946f957.png" },
    { id: 2, name: "Dothraki Warrior T-Shirt", price: 120, category: "clothing", description: "Premium cotton t-shirt with Dothraki design", image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/d644663a-be52-4701-bb48-663cca5978ba.png" },
    { id: 3, name: "Pridelands Adventure Hoodie", price: 160, category: "clothing", description: "Comfortable hoodie inspired by Pridelands adventures", image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/63bea584-17f5-4294-858f-b9a66ab68ed1.png" },
    { id: 4, name: "Aquaman Symbol Necklace", price: 450, category: "accessories", description: "Sterling silver necklace with Aquaman symbol", image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/a99073a1-a03a-488a-8035-2a317e8ce3aa.png" },
    { id: 5, name: "Khal Drogo Leather Bracelet", price: 750, category: "accessories", description: "Handcrafted leather bracelet in warrior style", image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/19599a18-d9e1-413d-9081-4b814f0d162c.png" },
    { id: 6, name: "Aquaman Movie Poster", price: 50, category: "collectibles", description: "Limited edition movie poster signed print", image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/9071137d-f2b1-4a1c-b273-e1a524ad5879.png" },
    { id: 7, name: "Ocean Guardian Tank Top", price: 39, category: "clothing", description: "Athletic tank top with ocean-themed design", image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/15520fd1-c79d-44ac-b8aa-8b97e2e4593a.png" },
    { id: 8, name: "Trident Keychain", price: 115, category: "accessories", description: "Metal trident keychain with blue accents", image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/3784bc60-8ec9-4445-8c96-8594a7b55a5c.png" },
    { id: 9, name: "Jason Momoa Workout Guide", price: 490, category: "collectibles", description: "Complete fitness and workout guide book", image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/384df91b-e2e1-48d1-a288-afece784a2e1.png" },
    { id: 10, name: "Atlantean Battle Armor Piece", price: 499, category: "collectibles", description: "Authentic replica piece of Atlantean battle armor, a true collector's item.", image: "/atlantean_battle_armor.png" },
    { id: 11, name: "Momoa Signature Coffee Blend", price: 22, category: "collectibles", description: "Exclusive coffee blend personally selected by Jason Momoa, a bold taste for warriors.", image: "/momoa_coffee_blend.png" },
    { id: 12, name: "Kaiwi'ula Beach Towel", price: 30, category: "accessories", description: "Soft and absorbent beach towel with stunning Hawaiian-inspired designs.", image: "/kaiwiula_beach_towel.png" },
    { id: 13, name: "Ocean Protector Rash Guard", price: 75, category: "clothing", description: "High-performance rash guard offering UV protection and comfort for all water activities.", image: "/ocean_protector_rash_guard.png" },
    { id: 14, name: "Mana Necklace", price: 650, category: "accessories", description: "Handcrafted necklace with a powerful mana symbol, embodying strength and spirit.", image: "/mana_necklace.png" },
    { id: 15, name: "'On The Roam' Travel Mug", price: 75, category: "accessories", description: "Durable insulated travel mug perfect for your daily adventures.", image: "/on_the_roam_travel_mug.png" }
  ];
  const addToCart = (product) => {
    setCartItems((prev) => {
      const existingItem = prev.find((item) => item.id === product.id);
      if (existingItem) {
        return prev.map(
          (item) => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      } else {
        return [...prev, { ...product, quantity: 1 }];
      }
    });
  };
  const updateQuantity = (id, change) => {
    setCartItems((prev) => {
      return prev.map((item) => {
        if (item.id === id) {
          const newQuantity = item.quantity + change;
          return newQuantity > 0 ? { ...item, quantity: newQuantity } : item;
        }
        return item;
      }).filter((item) => item.quantity > 0);
    });
  };
  const removeFromCart = (id) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };
  const getTotalPrice = () => {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gray-50", children: [
    /* @__PURE__ */ jsxDEV("a", { href: "#main-content", className: "sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 bg-orange-500 text-white px-4 py-2 z-50", children: "Skip to main content" }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 88,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Header,
      {
        cartItemCount: cartItems.length,
        showMobileMenu,
        setShowMobileMenu,
        setShowCart,
        setCurrentPage
      },
      void 0,
      false,
      {
        fileName: "<stdin>",
        lineNumber: 91,
        columnNumber: 7
      },
      this
    ),
    currentPage === "home" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(HeroSection, { setCurrentPage }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 101,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(FeaturedSections, { setCurrentPage }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 102,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(NewsletterSection, {}, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 103,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 100,
      columnNumber: 9
    }, this),
    currentPage === "shop" && /* @__PURE__ */ jsxDEV(
      ShopSection,
      {
        allProducts: products
      },
      void 0,
      false,
      {
        fileName: "<stdin>",
        lineNumber: 108,
        columnNumber: 9
      },
      this
    ),
    currentPage === "membership" && /* @__PURE__ */ jsxDEV(MembershipSection, {}, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 114,
      columnNumber: 9
    }, this),
    currentPage === "training" && /* @__PURE__ */ jsxDEV(TrainingSection, {}, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 118,
      columnNumber: 9
    }, this),
    currentPage === "about" && /* @__PURE__ */ jsxDEV(AboutSection, {}, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 122,
      columnNumber: 9
    }, this),
    currentPage === "login" && /* @__PURE__ */ jsxDEV(LoginPage, { setCurrentPage }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 126,
      columnNumber: 9
    }, this),
    currentPage === "contact" && /* @__PURE__ */ jsxDEV(ContactSection, {}, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 130,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      ShoppingCartSidebar,
      {
        showCart,
        setShowCart,
        cartItems,
        updateQuantity,
        removeFromCart,
        getTotalPrice
      },
      void 0,
      false,
      {
        fileName: "<stdin>",
        lineNumber: 133,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Footer, {}, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 142,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 87,
    columnNumber: 5
  }, this);
}
export {
  App as default
};
