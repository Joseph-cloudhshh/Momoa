import { jsxDEV } from "react/jsx-dev-runtime";
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card.jsx";
import { Button } from "../ui/button.jsx";
function ProductGrid({ products }) {
  const [imageLoaded, setImageLoaded] = useState({});
  return /* @__PURE__ */ jsxDEV("section", { id: "products", className: "py-16 md:py-24 bg-white", children: /* @__PURE__ */ jsxDEV("div", { className: "container mx-auto px-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "text-center mb-12 md:mb-16", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl sm:text-4xl md:text-5xl font-black text-gray-900 mb-3 md:mb-4 animate-fade-in", children: "PREMIUM COLLECTION" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 12,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-lg sm:text-xl text-gray-600 max-w-2xl mx-auto animate-fade-in-delay", children: "Engineered for champions. Crafted for legends. Every piece designed to elevate your performance." }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 15,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 11,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8", children: products.map((product, index) => /* @__PURE__ */ jsxDEV(Card, { className: "group hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 animate-fade-in", style: { animationDelay: `${index * 100}ms` }, children: [
      /* @__PURE__ */ jsxDEV(CardHeader, { className: "p-0 relative overflow-hidden", children: [
        /* @__PURE__ */ jsxDEV(
          "img",
          {
            src: product.image,
            alt: product.name,
            className: `w-full h-48 md:h-64 object-cover transition-transform duration-500 group-hover:scale-110 ${imageLoaded[product.id] ? "opacity-100" : "opacity-0"}`,
            onLoad: () => setImageLoaded((prev) => ({ ...prev, [product.id]: true }))
          },
          void 0,
          false,
          {
            fileName: "<stdin>",
            lineNumber: 24,
            columnNumber: 17
          },
          this
        ),
        !imageLoaded[product.id] && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-gray-200 animate-pulse" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 31,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "absolute top-4 right-4 bg-black/80 text-white px-3 py-1 rounded-full text-sm font-bold", children: product.category }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 33,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 23,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(CardContent, { className: "p-4 md:p-6", children: [
        /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-lg md:text-xl mb-2 text-gray-900", children: product.name }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 38,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(CardDescription, { className: "text-sm md:text-base mb-4 text-gray-600", children: product.description }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 39,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xl md:text-2xl font-bold text-orange-600", children: [
            "$",
            product.price.toFixed(2)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 41,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              as: "a",
              href: `mailto:management@prideofgypsies.online?subject=Purchase%20Inquiry%3A%20${encodeURIComponent(product.name)}%20%28%24${product.price.toFixed(2)}%29&body=I%20am%20interested%20in%20purchasing%20the%20${encodeURIComponent(product.name)}%20for%20%24${product.price.toFixed(2)}.%20Please%20send%20me%20more%20information%20on%20how%20to%20proceed%20with%20the%20purchase.`,
              className: "bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white px-4 md:px-6 py-2 font-bold transform hover:scale-105 transition-all duration-200",
              "aria-label": `Purchase ${product.name} now`,
              children: "Purchase Now"
            },
            void 0,
            false,
            {
              fileName: "<stdin>",
              lineNumber: 42,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 40,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 37,
        columnNumber: 15
      }, this)
    ] }, product.id, true, {
      fileName: "<stdin>",
      lineNumber: 22,
      columnNumber: 13
    }, this)) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 20,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 10,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 9,
    columnNumber: 5
  }, this);
}
export {
  ProductGrid
};
