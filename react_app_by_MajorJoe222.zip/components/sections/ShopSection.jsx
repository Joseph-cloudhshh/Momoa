import { jsxDEV } from "react/jsx-dev-runtime";
import React, { useState } from "react";
import { CategoryFilter } from "./CategoryFilter.jsx";
import { ProductGrid } from "./ProductGrid.jsx";
import { NewsletterSection } from "./NewsletterSection.jsx";
function ShopSection({ allProducts }) {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const fanCards = [
    { id: 101, name: "Bronze Warrior Fan Card", price: 750, category: "fan-cards", description: "Collectible Bronze Tier Fan Card. Limited edition, exclusive design.", image: "/fan_card_bronze.png" },
    { id: 102, name: "Silver Trident Fan Card", price: 1500, category: "fan-cards", description: "Collectible Silver Tier Fan Card with ocean wave motifs and unique artwork.", image: "/fan_card_silver.png" },
    { id: 103, name: "Gold Legend Fan Card", price: 3e3, category: "fan-cards", description: "Ultimate Gold Tier Fan Card. Premium embossed, featuring a prominent Jason Momoa portrait.", image: "/fan_card_gold.png" }
  ];
  const allShopItems = [...allProducts, ...fanCards];
  const availableCategories = [
    { key: "all", label: "All Items" },
    { key: "clothing", label: "Clothing" },
    { key: "accessories", label: "Accessories" },
    { key: "collectibles", label: "Collectibles" },
    { key: "fan-cards", label: "Fan Cards" }
  ];
  const filteredShopItems = selectedCategory === "all" ? allShopItems : allShopItems.filter((item) => item.category === selectedCategory);
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gray-50", children: [
    /* @__PURE__ */ jsxDEV("section", { className: "py-16 md:py-24 bg-gradient-to-br from-gray-900 via-black to-gray-800 text-white text-center", children: /* @__PURE__ */ jsxDEV("div", { className: "container mx-auto px-4", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-white mb-4 animate-fade-in", children: [
        "THE OFFICIAL ",
        /* @__PURE__ */ jsxDEV("span", { className: "text-orange-500", children: "SHOP" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 34,
          columnNumber: 26
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 33,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-base sm:text-lg md:text-xl text-gray-300 max-w-3xl mx-auto animate-fade-in-delay", children: "Explore premium merchandise, exclusive collectibles, and the legendary Fan Cards. Find gear that embodies the spirit of a true warrior." }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 36,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 32,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 31,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      CategoryFilter,
      {
        categories: availableCategories,
        selectedCategory,
        setSelectedCategory
      },
      void 0,
      false,
      {
        fileName: "<stdin>",
        lineNumber: 43,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      ProductGrid,
      {
        products: filteredShopItems
      },
      void 0,
      false,
      {
        fileName: "<stdin>",
        lineNumber: 49,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(NewsletterSection, {}, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 53,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 30,
    columnNumber: 5
  }, this);
}
export {
  ShopSection
};
