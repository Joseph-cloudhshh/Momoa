import { jsxDEV } from "react/jsx-dev-runtime";
import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../ui/card.jsx";
import { Button } from "../ui/button.jsx";
import { Mail, Phone, MapPin, Briefcase } from "lucide-react";
function ContactSection() {
  const handleRequestCallAccess = (e) => {
    e.preventDefault();
    alert("Access to this exclusive direct line is reserved. Please inquire through general support for special access requests.");
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-800 py-16 md:py-24 text-white", children: /* @__PURE__ */ jsxDEV("div", { className: "container mx-auto px-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "text-center mb-12 md:mb-16", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-white mb-4 animate-fade-in", children: [
        "GET IN ",
        /* @__PURE__ */ jsxDEV("span", { className: "text-orange-500", children: "TOUCH" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 17,
          columnNumber: 20
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 16,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-base sm:text-lg md:text-xl text-gray-300 max-w-3xl mx-auto animate-fade-in-delay", children: "We're here to help! Reach out to us for any inquiries, support, or collaborations." }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 19,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 15,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto", children: [
      /* @__PURE__ */ jsxDEV(Card, { className: "bg-gray-800 border-orange-500 border-2 shadow-xl hover:shadow-orange-500/20 transition-all duration-300 transform hover:-translate-y-2 animate-fade-in-up", children: [
        /* @__PURE__ */ jsxDEV(CardHeader, { className: "text-center", children: [
          /* @__PURE__ */ jsxDEV(Mail, { className: "w-12 h-12 text-orange-500 mx-auto mb-4" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 28,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-2xl font-bold", children: "General Inquiries" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 29,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CardDescription, { className: "text-gray-400", children: "For general questions, fan support, and fast responses regarding merchandise." }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 30,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 27,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(CardContent, { className: "text-center", children: [
          /* @__PURE__ */ jsxDEV(
            "a",
            {
              href: "mailto:management@prideofgypsies.online?subject=General%20Inquiry%20from%20Website",
              className: "text-orange-400 hover:text-orange-300 text-lg font-semibold block mb-4",
              children: "management@prideofgypsies.online"
            },
            void 0,
            false,
            {
              fileName: "<stdin>",
              lineNumber: 35,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              as: "a",
              href: "mailto:management@prideofgypsies.online?subject=Website%20Contact",
              className: "w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white py-3 font-bold",
              children: "Send an Email"
            },
            void 0,
            false,
            {
              fileName: "<stdin>",
              lineNumber: 41,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 34,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 26,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "bg-gray-800 border-gray-700 shadow-xl hover:shadow-white/20 transition-all duration-300 transform hover:-translate-y-2 animate-fade-in-up", style: { animationDelay: "150ms" }, children: [
        /* @__PURE__ */ jsxDEV(CardHeader, { className: "text-center", children: [
          /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-12 h-12 text-blue-500 mx-auto mb-4" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 54,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-2xl font-bold", children: "Consulting & Partnerships" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 55,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CardDescription, { className: "text-gray-400", children: "For business consultations, collaborations, or partnership inquiries." }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 56,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 53,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(CardContent, { className: "text-center", children: [
          /* @__PURE__ */ jsxDEV(
            "a",
            {
              href: "mailto:prideofgypsies@consultant.com?subject=Consulting%20Inquiry%20from%20Website",
              className: "text-blue-400 hover:text-blue-300 text-lg font-semibold block mb-4",
              children: "prideofgypsies@consultant.com"
            },
            void 0,
            false,
            {
              fileName: "<stdin>",
              lineNumber: 61,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              as: "a",
              href: "mailto:prideofgypsies@consultant.com?subject=Consulting%20Inquiry",
              variant: "outline",
              className: "w-full border-blue-600 text-blue-300 hover:bg-blue-700 hover:text-white py-3 font-bold",
              children: "Contact for Business"
            },
            void 0,
            false,
            {
              fileName: "<stdin>",
              lineNumber: 67,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 60,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 52,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "bg-gray-800 border-gray-700 shadow-xl hover:shadow-white/20 transition-all duration-300 transform hover:-translate-y-2 animate-fade-in-up", style: { animationDelay: "300ms" }, children: [
        /* @__PURE__ */ jsxDEV(CardHeader, { className: "text-center", children: [
          /* @__PURE__ */ jsxDEV(Phone, { className: "w-12 h-12 text-gray-400 mx-auto mb-4" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 81,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-2xl font-bold", children: "Exclusive Direct Line" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 82,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CardDescription, { className: "text-gray-400", children: "A highly exclusive line for paramount inquiries. Reserved for special access." }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 83,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 80,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(CardContent, { className: "text-center", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-semibold mb-4 text-gray-300", children: /* @__PURE__ */ jsxDEV("span", { className: "blur-sm select-none", children: " +1 (808) 555-1234 " }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 89,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 88,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: handleRequestCallAccess,
              variant: "outline",
              className: "w-full border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white py-3 font-bold",
              children: "Request Call Access"
            },
            void 0,
            false,
            {
              fileName: "<stdin>",
              lineNumber: 91,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 87,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 79,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 24,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "max-w-4xl mx-auto mt-16 text-center", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-3xl font-bold text-white mb-6 animate-fade-in-up", children: "Connect with Us on Social Media" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 103,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-lg text-gray-400 mb-8 animate-fade-in-up", style: { animationDelay: "100ms" }, children: "Follow us to stay updated on the latest news, events, and behind-the-scenes content." }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 106,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center space-x-6 animate-fade-in-up", style: { animationDelay: "200ms" }, children: [
        /* @__PURE__ */ jsxDEV("a", { href: "#", className: "text-gray-400 hover:text-orange-500 transition-colors text-3xl", "aria-label": "Visit us on Instagram", children: /* @__PURE__ */ jsxDEV("i", { className: "fab fa-instagram" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 111,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 110,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("a", { href: "#", className: "text-gray-400 hover:text-orange-500 transition-colors text-3xl", "aria-label": "Visit us on Twitter", children: /* @__PURE__ */ jsxDEV("i", { className: "fab fa-twitter" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 114,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 113,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("a", { href: "#", className: "text-gray-400 hover:text-orange-500 transition-colors text-3xl", "aria-label": "Visit us on Facebook", children: /* @__PURE__ */ jsxDEV("i", { className: "fab fa-facebook" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 117,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 116,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 109,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 102,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 14,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 13,
    columnNumber: 5
  }, this);
}
export {
  ContactSection
};
