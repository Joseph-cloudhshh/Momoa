import { jsxDEV } from "react/jsx-dev-runtime";
import React, { useState } from "react";
import { Button } from "../ui/button.jsx";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card.jsx";
import { Input } from "../ui/input.jsx";
import { Label } from "../ui/label.jsx";
import { User, Key } from "lucide-react";
function LoginPage({ setCurrentPage }) {
  const [fanId, setFanId] = useState("");
  const [licenseKey, setLicenseKey] = useState("");
  const [error, setError] = useState("");
  const handleSubmit = (e) => {
    e.preventDefault();
    setError("");
    if (!fanId || !licenseKey) {
      setError("Please enter both your Fan/Membership ID and License Key.");
      return;
    }
    if (fanId === "jasonfan" && licenseKey === "legendary2024") {
      alert("Login successful! Welcome, Legendary Fan.");
      setCurrentPage("home");
    } else {
      setError("Invalid Fan/Membership ID or License Key. Please try again.");
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-800 flex items-center justify-center py-16 px-4", children: /* @__PURE__ */ jsxDEV(Card, { className: "w-full max-w-md bg-gray-800 text-white border-orange-500 border-2 shadow-2xl animate-fade-in-up", children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "text-center", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-r from-orange-500 to-orange-700 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(User, { className: "w-10 h-10 text-white" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 37,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 36,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-3xl font-bold text-white mb-2", children: "Member Login" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 39,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(CardDescription, { className: "text-lg text-gray-300", children: "Access your exclusive fan portal." }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 40,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 35,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-6", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: "fanId", className: "block text-sm font-medium text-gray-300 mb-2", children: "Fan/Membership ID" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 47,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            id: "fanId",
            type: "text",
            placeholder: "Your Fan or Membership ID",
            value: fanId,
            onChange: (e) => setFanId(e.target.value),
            className: "bg-gray-700 border-gray-600 text-white placeholder:text-gray-400 focus:border-orange-500",
            "aria-label": "Fan or Membership ID"
          },
          void 0,
          false,
          {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 46,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: "licenseKey", className: "block text-sm font-medium text-gray-300 mb-2", children: "License Key" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 59,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            id: "licenseKey",
            type: "password",
            placeholder: "Your unique License Key",
            value: licenseKey,
            onChange: (e) => setLicenseKey(e.target.value),
            className: "bg-gray-700 border-gray-600 text-white placeholder:text-gray-400 focus:border-orange-500",
            "aria-label": "License Key"
          },
          void 0,
          false,
          {
            fileName: "<stdin>",
            lineNumber: 60,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 58,
        columnNumber: 13
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { className: "text-red-400 text-sm text-center", children: error }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 71,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          type: "submit",
          className: "w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white py-3 text-lg font-bold transform hover:scale-105 transition-all duration-200",
          children: "Sign In"
        },
        void 0,
        false,
        {
          fileName: "<stdin>",
          lineNumber: 73,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col space-y-2 mt-4 text-center", children: [
        /* @__PURE__ */ jsxDEV("a", { href: "#", className: "text-orange-400 hover:text-orange-300 text-sm transition-colors", children: "Forgot ID or License Key?" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 80,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "a",
          {
            href: "mailto:management@prideofgypsies.online?subject=Inquiry%20to%20Become%20a%20Fan",
            className: "text-gray-300 hover:text-white text-sm transition-colors font-semibold",
            target: "_blank",
            rel: "noopener noreferrer",
            children: "Become a Fan"
          },
          void 0,
          false,
          {
            fileName: "<stdin>",
            lineNumber: 83,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 79,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 45,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 44,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 34,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 33,
    columnNumber: 5
  }, this);
}
export {
  LoginPage
};
