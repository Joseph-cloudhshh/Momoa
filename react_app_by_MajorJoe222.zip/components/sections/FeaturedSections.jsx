import { jsxDEV } from "react/jsx-dev-runtime";
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card.jsx";
import { Button } from "../ui/button.jsx";
function FeaturedSections({ setCurrentPage }) {
  const [imageLoaded, setImageLoaded] = useState({});
  const featuredItems = [
    {
      id: "shop",
      title: "Shop Exclusive Gear",
      description: "Discover premium apparel, collectibles, and fan cards.",
      image: "/ocean_protector_rash_guard.png",
      page: "shop",
      buttonText: "Explore Shop",
      icon: "\u{1F6CD}\uFE0F"
    },
    {
      id: "membership",
      title: "Become a Legend Member",
      description: "Unlock elite access, discounts, and unique experiences.",
      image: "/fan_card_gold.png",
      page: "membership",
      buttonText: "Join Membership",
      icon: "\u2B50"
    },
    {
      id: "training",
      title: "Elite Warrior Training",
      description: "Train with Jason Momoa's personalized program.",
      image: "/jason_momoa_aquaman_hero.png",
      page: "training",
      buttonText: "Start Training",
      icon: "\u{1F4AA}"
    },
    {
      id: "about",
      title: "The Man Behind the Legend",
      description: "Learn about Jason Momoa and his inspiring team.",
      image: "/coni_momoa.png",
      page: "about",
      buttonText: "Learn More",
      icon: "\u{1F919}"
    }
  ];
  return /* @__PURE__ */ jsxDEV("section", { className: "py-16 md:py-24 bg-gray-900 text-white", children: /* @__PURE__ */ jsxDEV("div", { className: "container mx-auto px-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "text-center mb-12 md:mb-16", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl sm:text-4xl md:text-5xl font-black text-white mb-3 animate-fade-in", children: [
        "OUR ",
        /* @__PURE__ */ jsxDEV("span", { className: "text-orange-500", children: "LEGENDARY" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 52,
          columnNumber: 17
        }, this),
        " WORLD"
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 51,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-lg sm:text-xl text-gray-400 max-w-2xl mx-auto animate-fade-in-delay", children: "Dive deeper into the universe of Jason Momoa." }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 54,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 50,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8", children: featuredItems.map((item, index) => /* @__PURE__ */ jsxDEV(Card, { className: "group flex flex-col h-full bg-gray-800 text-white border-gray-700 hover:border-orange-500 shadow-xl hover:shadow-orange-500/20 transition-all duration-300 transform hover:-translate-y-2 animate-fade-in", style: { animationDelay: `${index * 150}ms` }, children: [
      /* @__PURE__ */ jsxDEV(CardHeader, { className: "p-0 relative overflow-hidden h-48", children: [
        /* @__PURE__ */ jsxDEV(
          "img",
          {
            src: item.image,
            alt: item.title,
            className: `w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 ${imageLoaded[item.id] ? "opacity-100" : "opacity-0"}`,
            onLoad: () => setImageLoaded((prev) => ({ ...prev, [item.id]: true }))
          },
          void 0,
          false,
          {
            fileName: "<stdin>",
            lineNumber: 63,
            columnNumber: 17
          },
          this
        ),
        !imageLoaded[item.id] && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-gray-700 animate-pulse" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 70,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-black/40 flex items-end p-4", children: /* @__PURE__ */ jsxDEV("span", { className: "text-4xl leading-none", children: item.icon }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 73,
          columnNumber: 21
        }, this) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 72,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 62,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(CardContent, { className: "flex-grow p-4 md:p-6 flex flex-col justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-xl md:text-2xl mb-2 text-orange-400", children: item.title }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 78,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(CardDescription, { className: "text-sm md:text-base mb-4 text-gray-300", children: item.description }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 79,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 77,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: () => setCurrentPage(item.page),
            className: "w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white px-4 py-2 font-bold transform hover:scale-105 transition-all duration-200 mt-4",
            "aria-label": item.buttonText,
            children: item.buttonText
          },
          void 0,
          false,
          {
            fileName: "<stdin>",
            lineNumber: 81,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 76,
        columnNumber: 15
      }, this)
    ] }, item.id, true, {
      fileName: "<stdin>",
      lineNumber: 61,
      columnNumber: 13
    }, this)) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 59,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 49,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 48,
    columnNumber: 5
  }, this);
}
export {
  FeaturedSections
};
