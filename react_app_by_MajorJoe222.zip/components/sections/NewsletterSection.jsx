import { jsxDEV } from "react/jsx-dev-runtime";
import React from "react";
import { Input } from "../ui/input.jsx";
import { Button } from "../ui/button.jsx";
function NewsletterSection() {
  return /* @__PURE__ */ jsxDEV("section", { className: "bg-gray-900 text-white py-16", children: /* @__PURE__ */ jsxDEV("div", { className: "container mx-auto px-4 text-center", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl font-bold mb-4", children: "Stay Updated" }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 9,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-gray-300 mb-8", children: "Get notified about new collections and exclusive offers" }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 10,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "max-w-md mx-auto flex gap-4", children: [
      /* @__PURE__ */ jsxDEV(
        Input,
        {
          type: "email",
          placeholder: "Enter your email",
          className: "flex-1 bg-white text-black"
        },
        void 0,
        false,
        {
          fileName: "<stdin>",
          lineNumber: 12,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          as: "a",
          href: "mailto:management@prideofgypsies.online?subject=Newsletter%20Subscription%20Request",
          className: "bg-orange-500 hover:bg-orange-600 font-bold",
          children: "Subscribe"
        },
        void 0,
        false,
        {
          fileName: "<stdin>",
          lineNumber: 17,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 11,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 8,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 7,
    columnNumber: 5
  }, this);
}
export {
  NewsletterSection
};
