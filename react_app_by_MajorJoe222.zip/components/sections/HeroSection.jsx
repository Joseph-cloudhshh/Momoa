import { jsxDEV } from "react/jsx-dev-runtime";
import React from "react";
import { Button } from "../ui/button.jsx";
function HeroSection({ setCurrentPage }) {
  const heroImage = "/jason_momoa_aquaman_hero.png";
  return /* @__PURE__ */ jsxDEV("section", { id: "home", className: "relative bg-gradient-to-r from-gray-900 via-black to-gray-900 text-white py-20 md:py-32 overflow-hidden", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-black/40 z-10" }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 9,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "container mx-auto px-4 relative z-20", children: /* @__PURE__ */ jsxDEV("div", { className: "grid md:grid-cols-2 gap-8 md:gap-12 items-center", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "animate-fade-in-up", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black mb-4 md:mb-6 leading-tight", children: [
          "JUST DO",
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 14,
            columnNumber: 22
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-orange-500 animate-pulse", children: "LEGENDARY" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 15,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 13,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-lg sm:text-xl md:text-2xl mb-6 md:mb-8 text-gray-300 font-light", children: "Unleash your inner warrior with premium performance gear crafted for champions." }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 17,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row gap-3 md:gap-4", children: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "lg",
              className: "bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white px-8 md:px-12 py-3 md:py-4 text-base md:text-lg font-bold transform hover:scale-105 transition-all duration-200",
              onClick: () => setCurrentPage("shop"),
              children: "Shop Premium Collection"
            },
            void 0,
            false,
            {
              fileName: "<stdin>",
              lineNumber: 21,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "lg",
              variant: "outline",
              className: "border-white text-white hover:bg-white hover:text-black px-8 md:px-12 py-3 md:py-4 text-base md:text-lg font-bold backdrop-blur-sm",
              onClick: () => setCurrentPage("training"),
              children: "Explore Training"
            },
            void 0,
            false,
            {
              fileName: "<stdin>",
              lineNumber: 28,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 20,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 12,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative mt-8 md:mt-0", children: /* @__PURE__ */ jsxDEV("div", { className: "relative overflow-hidden rounded-2xl shadow-2xl group", children: [
        /* @__PURE__ */ jsxDEV(
          "img",
          {
            src: heroImage,
            alt: "Jason Momoa in iconic Aquaman costume with trident, standing heroically against ocean backdrop with dramatic lighting",
            className: "w-full h-64 md:h-96 object-cover transform group-hover:scale-110 transition-transform duration-700"
          },
          void 0,
          false,
          {
            fileName: "<stdin>",
            lineNumber: 40,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 45,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 39,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 38,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 11,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 10,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 8,
    columnNumber: 5
  }, this);
}
export {
  HeroSection
};
