import { jsxDEV } from "react/jsx-dev-runtime";
import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card.jsx";
import { User, Heart, Briefcase, Star } from "lucide-react";
function AboutSection() {
  const teamMembers = [
    {
      name: "Coni Momoa",
      role: "Jason Momoa's Hero and Inspiration",
      description: "Coni Momoa, Jason's beloved mother, is his guiding light and the enduring source of his strength and values. Her unwavering support and spirit inspire him in every endeavor.",
      image: "/coni_momoa.png",
      icon: /* @__PURE__ */ jsxDEV(Heart, { className: "w-6 h-6 text-orange-500" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 12,
        columnNumber: 13
      }, this)
    },
    {
      name: "Blaine Halvorson",
      role: "Business Partner & Personal Assistant",
      description: "Blaine Halvorson is a key pillar in Jason Momoa's ventures, expertly managing his business partnerships and assisting in his day-to-day professional life, ensuring seamless operations.",
      image: "/blaine_halvorson.png",
      icon: /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-6 h-6 text-blue-500" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 19,
        columnNumber: 13
      }, this)
    },
    {
      name: "Adria Arjona",
      role: "Caretaker, Business Partner & Vice Head of Management",
      description: "Adria Arjona provides crucial support across multiple facets of Jason Momoa's life, from personal caretaking to strategic business partnerships and leadership in management.",
      image: "/adria_arjona.png",
      icon: /* @__PURE__ */ jsxDEV(Star, { className: "w-6 h-6 text-yellow-500" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 26,
        columnNumber: 13
      }, this)
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-800 text-white", children: [
    /* @__PURE__ */ jsxDEV("section", { className: "py-20 md:py-32 bg-cover bg-center", style: { backgroundImage: `url('/jason_momoa_aquaman_hero.png')` }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-black/60 inset-0 absolute" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 34,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "container mx-auto px-4 relative z-10 text-center", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-4xl sm:text-5xl md:text-6xl font-black mb-4 animate-fade-in", children: [
          "ABOUT ",
          /* @__PURE__ */ jsxDEV("span", { className: "text-orange-500", children: "JASON MOMOA" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 37,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 36,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-lg sm:text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto animate-fade-in-delay", children: "The Vision, The Man, The Legend Behind the Brand." }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 39,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 35,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 33,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "py-16 md:py-24 bg-gray-900", children: /* @__PURE__ */ jsxDEV("div", { className: "container mx-auto px-4", children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-4xl mx-auto text-center", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-3xl sm:text-4xl font-bold text-orange-500 mb-6 animate-fade-in-up", children: "A True Warrior, On and Off Screen" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 49,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-lg text-gray-300 leading-relaxed mb-6 animate-fade-in-up", style: { animationDelay: "100ms" }, children: "Jason Momoa is more than just an actor; he's a force of nature, an environmental advocate, and a devoted family man. Known globally for his powerful roles, particularly as Aquaman and Khal Drogo, Jason brings an unparalleled authenticity and spirit to every character he embodies." }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 52,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-lg text-gray-300 leading-relaxed mb-6 animate-fade-in-up", style: { animationDelay: "200ms" }, children: "Beyond the screen, Jason is deeply committed to protecting our planet's oceans and natural resources, notably through his Mananalu Water company, which champions sustainable hydration. He inspires millions with his dedication to a healthy, adventurous lifestyle." }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 55,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-orange-400 leading-relaxed animate-fade-in-up", style: { animationDelay: "300ms" }, children: "A single dad caring for his beloved children, Jason embodies strength, compassion, and resilience, constantly striving to be the best role model for them and his global fanbase." }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 58,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 48,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 47,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 46,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "py-16 md:py-24 bg-black", children: /* @__PURE__ */ jsxDEV("div", { className: "container mx-auto px-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-center mb-12 md:mb-16", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-3xl sm:text-4xl font-bold text-white mb-4 animate-fade-in", children: [
          "THE ",
          /* @__PURE__ */ jsxDEV("span", { className: "text-orange-500", children: "LEGENDARY" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 70,
            columnNumber: 19
          }, this),
          " TEAM"
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 69,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-lg text-gray-400 max-w-2xl mx-auto animate-fade-in-delay", children: "Behind every legend is an incredible team. Meet the key individuals who empower Jason Momoa's vision." }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 72,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 68,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8", children: teamMembers.map((member, index) => /* @__PURE__ */ jsxDEV(Card, { className: "bg-gray-900 text-white border-gray-700 shadow-xl hover:shadow-orange-500/20 transition-all duration-300 animate-fade-in-up", style: { animationDelay: `${index * 150 + 400}ms` }, children: [
        /* @__PURE__ */ jsxDEV(CardHeader, { className: "flex flex-col items-center pt-6 pb-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "relative w-32 h-32 rounded-full overflow-hidden mb-4 border-4 border-orange-500 group-hover:border-orange-400 transition-colors duration-300", children: /* @__PURE__ */ jsxDEV(
            "img",
            {
              src: member.image,
              alt: member.name,
              className: "w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500"
            },
            void 0,
            false,
            {
              fileName: "<stdin>",
              lineNumber: 82,
              columnNumber: 21
            },
            this
          ) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 81,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-2xl font-bold text-white mb-1", children: member.name }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 88,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(CardDescription, { className: "text-orange-400 text-md flex items-center gap-2", children: [
            member.icon,
            " ",
            member.role
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 89,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 80,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(CardContent, { className: "px-6 pb-6 text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-300 text-base leading-relaxed", children: member.description }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 94,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 93,
          columnNumber: 17
        }, this)
      ] }, index, true, {
        fileName: "<stdin>",
        lineNumber: 79,
        columnNumber: 15
      }, this)) }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 77,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 67,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 66,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 31,
    columnNumber: 5
  }, this);
}
export {
  AboutSection
};
