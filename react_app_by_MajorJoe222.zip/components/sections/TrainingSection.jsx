import { jsxDEV } from "react/jsx-dev-runtime";
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "../ui/card.jsx";
import { Button } from "../ui/button.jsx";
import { Check, Dumbbell, Clock, Video, Droplet, Truck, MessageSquare } from "lucide-react";
function TrainingSection() {
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const trainingPlan = {
    name: "Aqua Warrior Training Program",
    priceWeekly: 750,
    priceMonthly: 2500,
    duration: "Per Month",
    description: "Unleash your strength and transform with Jason Momoa's exclusive training regimen.",
    features: [
      { text: "Unlimited Mananalu Water Supply", icon: /* @__PURE__ */ jsxDEV(Droplet, { className: "w-4 h-4" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 16,
        columnNumber: 56
      }, this) },
      { text: "Weekly Premium Training Equipment Delivery", icon: /* @__PURE__ */ jsxDEV(Truck, { className: "w-4 h-4" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 17,
        columnNumber: 67
      }, this) },
      { text: "3x Weekly 1-on-1 Facetime Sessions with Jason Momoa", icon: /* @__PURE__ */ jsxDEV(Video, { className: "w-4 h-4" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 18,
        columnNumber: 76
      }, this) },
      { text: "Personalized Workout Plans & Progress Tracking", icon: /* @__PURE__ */ jsxDEV(Dumbbell, { className: "w-4 h-4" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 19,
        columnNumber: 71
      }, this) },
      { text: "Customized Nutrition & Meal Prep Guidance", icon: /* @__PURE__ */ jsxDEV(Check, { className: "w-4 h-4" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 20,
        columnNumber: 66
      }, this) },
      { text: "24/7 Direct Access to Fitness Experts via Chat", icon: /* @__PURE__ */ jsxDEV(MessageSquare, { className: "w-4 h-4" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 21,
        columnNumber: 71
      }, this) },
      { text: "Exclusive Access to the Warrior Community Forum", icon: /* @__PURE__ */ jsxDEV(Clock, { className: "w-4 h-4" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 22,
        columnNumber: 72
      }, this) },
      { text: "Early Enrollment in Advanced Challenges & Retreats", icon: /* @__PURE__ */ jsxDEV(Check, { className: "w-4 h-4" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 23,
        columnNumber: 75
      }, this) }
    ],
    callToAction: "Join the Training"
  };
  const handleSignUp = () => {
    setShowPaymentModal(true);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-800 py-16 md:py-24", children: /* @__PURE__ */ jsxDEV("div", { className: "container mx-auto px-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "text-center mb-12 md:mb-16", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-white mb-4 animate-fade-in", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-orange-500", children: "JASON MOMOA" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 37,
          columnNumber: 13
        }, this),
        " ELITE TRAINING"
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 36,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-base sm:text-lg md:text-xl text-gray-300 max-w-3xl mx-auto animate-fade-in-delay", children: "Train like a legend. Get personalized guidance, top-tier equipment, and direct access to Jason Momoa for your ultimate physical transformation." }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 39,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 35,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "max-w-xl mx-auto", children: /* @__PURE__ */ jsxDEV(Card, { className: "flex flex-col h-full border-orange-500 border-2 shadow-2xl scale-100 bg-gradient-to-br from-gray-800 to-gray-900 text-white animate-fade-in", children: [
      /* @__PURE__ */ jsxDEV(CardHeader, { className: "text-center pb-0", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-r from-orange-500 to-orange-700 flex items-center justify-center animate-bounce-slow", children: /* @__PURE__ */ jsxDEV(Dumbbell, { className: "w-10 h-10 text-white" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 48,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 47,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-4xl font-bold text-white mb-2", children: trainingPlan.name }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 50,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(CardDescription, { className: "text-lg text-gray-300", children: trainingPlan.description }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 51,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xl text-gray-400 mt-4", children: [
          "Weekly Plan: ",
          /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-orange-400", children: [
            "$",
            trainingPlan.priceWeekly.toLocaleString()
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 52,
            columnNumber: 70
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 52,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-6xl font-extrabold text-orange-500 my-4", children: [
          "$",
          trainingPlan.priceMonthly.toLocaleString()
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 53,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-400 mb-4", children: [
          "per ",
          trainingPlan.duration,
          " (Save $500!)"
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 54,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 46,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(CardContent, { className: "flex-grow p-6 pt-0", children: /* @__PURE__ */ jsxDEV("ul", { className: "space-y-4 text-gray-300", children: trainingPlan.features.map((feature, index) => /* @__PURE__ */ jsxDEV("li", { className: "flex items-start text-lg", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-6 h-6 mr-3 flex-shrink-0 text-orange-500", children: feature.icon }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 60,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: feature.text }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 61,
          columnNumber: 21
        }, this)
      ] }, index, true, {
        fileName: "<stdin>",
        lineNumber: 59,
        columnNumber: 19
      }, this)) }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 57,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 56,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(CardFooter, { className: "p-6 pt-0 mt-auto", children: /* @__PURE__ */ jsxDEV(
        Button,
        {
          onClick: handleSignUp,
          className: "w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white py-4 text-xl font-bold transform hover:scale-105 transition-all duration-200",
          children: trainingPlan.callToAction
        },
        void 0,
        false,
        {
          fileName: "<stdin>",
          lineNumber: 67,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 66,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 45,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 44,
      columnNumber: 9
    }, this),
    showPaymentModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-800 rounded-2xl p-8 max-w-md w-full border border-gray-700", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-white mb-4", children: "Confirm Your Training Program" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 81,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-gray-300 mb-6", children: [
        "You're enrolling in the ",
        /* @__PURE__ */ jsxDEV("span", { className: "text-orange-500 font-bold", children: trainingPlan.name }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 83,
          columnNumber: 41
        }, this),
        " for ",
        /* @__PURE__ */ jsxDEV("span", { className: "text-orange-500 font-bold", children: [
          "$",
          trainingPlan.priceMonthly.toLocaleString(),
          " ",
          trainingPlan.duration
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 83,
          columnNumber: 116
        }, this),
        "."
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 82,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: () => setShowPaymentModal(false),
            className: "w-full bg-gray-700 hover:bg-gray-600 text-white py-3 font-bold",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "<stdin>",
            lineNumber: 86,
            columnNumber: 17
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            as: "a",
            href: `mailto:management@prideofgypsies.online?subject=${encodeURIComponent(`Training Program Inquiry: ${trainingPlan.name} - $${trainingPlan.priceMonthly.toLocaleString()} ${trainingPlan.duration}`)}&body=${encodeURIComponent(`Dear Management Team,

I am interested in enrolling in the ${trainingPlan.name} for $${trainingPlan.priceMonthly.toLocaleString()} ${trainingPlan.duration}.

Please provide me with instructions on how to proceed with the payment.

Thank you.`)}`,
            className: "w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white py-3 font-bold",
            onClick: () => setShowPaymentModal(false),
            target: "_blank",
            rel: "noopener noreferrer",
            children: "Proceed to Payment"
          },
          void 0,
          false,
          {
            fileName: "<stdin>",
            lineNumber: 92,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 85,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 80,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 79,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 34,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 33,
    columnNumber: 5
  }, this);
}
export {
  TrainingSection
};
