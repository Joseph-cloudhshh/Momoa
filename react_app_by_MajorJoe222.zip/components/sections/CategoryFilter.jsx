import { jsxDEV } from "react/jsx-dev-runtime";
import React from "react";
import { Button } from "../ui/button.jsx";
function CategoryFilter({ categories, selectedCategory, setSelectedCategory }) {
  return /* @__PURE__ */ jsxDEV("section", { className: "bg-white py-8", children: /* @__PURE__ */ jsxDEV("div", { className: "container mx-auto px-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap justify-center gap-4", children: categories.map((category) => /* @__PURE__ */ jsxDEV(
    Button,
    {
      variant: selectedCategory === category.key ? "default" : "outline",
      onClick: () => setSelectedCategory(category.key),
      className: "px-6 py-2",
      children: category.label
    },
    category.key,
    false,
    {
      fileName: "<stdin>",
      lineNumber: 10,
      columnNumber: 13
    },
    this
  )) }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 8,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 7,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 6,
    columnNumber: 5
  }, this);
}
export {
  CategoryFilter
};
