import { jsxDEV } from "react/jsx-dev-runtime";
import React from "react";
function Footer() {
  return /* @__PURE__ */ jsxDEV("footer", { className: "bg-black text-white py-12", children: /* @__PURE__ */ jsxDEV("div", { className: "container mx-auto px-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "grid md:grid-cols-4 gap-8", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold mb-4", children: "JASON MOMOA" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 9,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-400", children: "Official merchandise store featuring exclusive collectibles and apparel." }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 10,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 8,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold mb-4", children: "Shop" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 13,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2 text-gray-400", children: [
          /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", className: "hover:text-white transition-colors", children: "Clothing" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 15,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 15,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", className: "hover:text-white transition-colors", children: "Accessories" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 16,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 16,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", className: "hover:text-white transition-colors", children: "Collectibles" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 17,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 17,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 14,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 12,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold mb-4", children: "Support" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 21,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2 text-gray-400", children: [
          /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "mailto:management@prideofgypsies.online", className: "hover:text-white transition-colors", children: "Contact Us" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 23,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 23,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", className: "hover:text-white transition-colors", children: "Shipping" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 24,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 24,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", className: "hover:text-white transition-colors", children: "Returns" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 25,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 25,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 22,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 20,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold mb-4", children: "Connect" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 29,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2 text-gray-400", children: [
          /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", className: "hover:text-white transition-colors", children: "Instagram" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 31,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 31,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", className: "hover:text-white transition-colors", children: "Twitter" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 32,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 32,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", className: "hover:text-white transition-colors", children: "Facebook" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 33,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 33,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 30,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 28,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 7,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "border-t border-gray-800 mt-8 pt-8 text-center text-gray-400", children: /* @__PURE__ */ jsxDEV("p", { children: "\xA9 2024 Jason Momoa Official Store. All rights reserved." }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 38,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 37,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 6,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 5,
    columnNumber: 5
  }, this);
}
export {
  Footer
};
