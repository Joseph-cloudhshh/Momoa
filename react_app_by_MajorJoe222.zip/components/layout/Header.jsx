import { jsxDEV } from "react/jsx-dev-runtime";
import React, { useState, useEffect } from "react";
import { Button } from "../ui/button.jsx";
import { Heart, Menu, Search, User, X, ShoppingCart } from "lucide-react";
function Header({ cartItemCount, showMobileMenu, setShowMobileMenu, setShowCart, setCurrentPage }) {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  const handleNavLinkClick = (page) => {
    setCurrentPage(page);
    setShowMobileMenu(false);
    if (page === "home" || page === "shop" || page === "training" || page === "membership" || page === "about" || page === "login" || page === "contact") {
      setTimeout(() => {
        window.scrollTo({ top: 0, behavior: "smooth" });
      }, 0);
    }
  };
  return /* @__PURE__ */ jsxDEV("header", { className: `${scrolled ? "bg-black/95 backdrop-blur-md shadow-lg" : "bg-black"} text-white sticky top-0 z-50 transition-all duration-300`, children: /* @__PURE__ */ jsxDEV("div", { className: "container mx-auto px-4 py-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-4", children: /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold", children: "JASON MOMOA" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 33,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 32,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("nav", { className: "hidden md:flex items-center space-x-8", children: [
        /* @__PURE__ */ jsxDEV("a", { onClick: () => handleNavLinkClick("home"), href: "#", className: "cursor-pointer hover:text-orange-400 transition-colors font-medium relative group", children: [
          "Home",
          /* @__PURE__ */ jsxDEV("span", { className: "absolute -bottom-1 left-0 w-0 h-0.5 bg-orange-400 transition-all duration-300 group-hover:w-full" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 40,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 38,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("a", { onClick: () => handleNavLinkClick("shop"), href: "#", className: "cursor-pointer hover:text-orange-400 transition-colors font-medium relative group", children: [
          "Shop",
          /* @__PURE__ */ jsxDEV("span", { className: "absolute -bottom-1 left-0 w-0 h-0.5 bg-orange-400 transition-all duration-300 group-hover:w-full" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 44,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 42,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("a", { onClick: () => handleNavLinkClick("about"), href: "#", className: "cursor-pointer hover:text-orange-400 transition-colors font-medium relative group", children: [
          "About",
          /* @__PURE__ */ jsxDEV("span", { className: "absolute -bottom-1 left-0 w-0 h-0.5 bg-orange-400 transition-all duration-300 group-hover:w-full" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 48,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 46,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("a", { onClick: () => handleNavLinkClick("contact"), href: "#", className: "cursor-pointer hover:text-orange-400 transition-colors font-medium relative group", children: [
          "Contact",
          /* @__PURE__ */ jsxDEV("span", { className: "absolute -bottom-1 left-0 w-0 h-0.5 bg-orange-400 transition-all duration-300 group-hover:w-full" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 52,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 50,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("a", { onClick: () => handleNavLinkClick("training"), href: "#", className: "cursor-pointer hover:text-orange-400 transition-colors font-medium", children: "Training" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 54,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("a", { onClick: () => handleNavLinkClick("membership"), href: "#", className: "cursor-pointer hover:text-orange-400 transition-colors font-medium", children: "Membership" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 55,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 37,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-4", children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", className: "hidden md:flex", children: /* @__PURE__ */ jsxDEV(Search, { className: "w-4 h-4" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 61,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 60,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: () => handleNavLinkClick("login"), children: /* @__PURE__ */ jsxDEV(User, { className: "w-4 h-4" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 64,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 63,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "ghost",
            size: "sm",
            onClick: () => alert("404 Not Found"),
            className: "relative",
            children: /* @__PURE__ */ jsxDEV(Heart, { className: "w-4 h-4" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 72,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "<stdin>",
            lineNumber: 66,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "ghost",
            size: "sm",
            onClick: () => setShowCart(true),
            className: "relative",
            "aria-label": `Shopping cart with ${cartItemCount} items`,
            children: [
              /* @__PURE__ */ jsxDEV(ShoppingCart, { className: "w-4 h-4" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 82,
                columnNumber: 15
              }, this),
              cartItemCount > 0 && /* @__PURE__ */ jsxDEV("span", { className: "absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-orange-500 text-xs font-bold text-white", children: cartItemCount }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 84,
                columnNumber: 17
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "<stdin>",
            lineNumber: 75,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "ghost",
            size: "sm",
            className: "md:hidden",
            onClick: () => setShowMobileMenu(!showMobileMenu),
            children: /* @__PURE__ */ jsxDEV(Menu, { className: "w-4 h-4" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 95,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "<stdin>",
            lineNumber: 89,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 59,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 31,
      columnNumber: 9
    }, this),
    showMobileMenu && /* @__PURE__ */ jsxDEV("nav", { className: "md:hidden mt-4 pb-4 border-t border-gray-700", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col space-y-2 mt-4", children: [
      /* @__PURE__ */ jsxDEV("a", { onClick: () => handleNavLinkClick("home"), href: "#", className: "cursor-pointer py-2 hover:text-orange-400 transition-colors font-medium", children: "Home" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 104,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("a", { onClick: () => handleNavLinkClick("shop"), href: "#", className: "cursor-pointer py-2 hover:text-orange-400 transition-colors font-medium", children: "Shop" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 105,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("a", { onClick: () => handleNavLinkClick("about"), href: "#", className: "cursor-pointer py-2 hover:text-orange-400 transition-colors font-medium", children: "About" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 106,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("a", { onClick: () => handleNavLinkClick("contact"), href: "#", className: "cursor-pointer py-2 hover:text-orange-400 transition-colors font-medium", children: "Contact" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 107,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("a", { onClick: () => handleNavLinkClick("training"), href: "#", className: "cursor-pointer py-2 hover:text-orange-400 transition-colors font-medium", children: "Training" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 108,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("a", { onClick: () => handleNavLinkClick("membership"), href: "#", className: "cursor-pointer py-2 hover:text-orange-400 transition-colors font-medium", children: "Membership" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 109,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("a", { onClick: () => handleNavLinkClick("login"), href: "#", className: "cursor-pointer py-2 hover:text-orange-400 transition-colors font-medium", children: "Login" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 110,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "ghost",
          size: "sm",
          onClick: () => setShowCart(true),
          className: "justify-start py-2 pl-2 pr-0 text-white hover:bg-gray-800 hover:text-orange-400 transition-colors font-medium relative",
          "aria-label": `Shopping cart with ${cartItemCount} items`,
          children: [
            /* @__PURE__ */ jsxDEV(ShoppingCart, { className: "w-4 h-4 mr-2" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 118,
              columnNumber: 17
            }, this),
            "Cart",
            cartItemCount > 0 && /* @__PURE__ */ jsxDEV("span", { className: "ml-2 flex h-4 w-4 items-center justify-center rounded-full bg-orange-500 text-xs font-bold text-white", children: cartItemCount }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 121,
              columnNumber: 19
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "<stdin>",
          lineNumber: 111,
          columnNumber: 15
        },
        this
      )
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 103,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 102,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 30,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 29,
    columnNumber: 5
  }, this);
}
export {
  Header
};
