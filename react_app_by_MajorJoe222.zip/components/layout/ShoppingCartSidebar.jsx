import { Fragment, jsxDEV } from "react/jsx-dev-runtime";
import React, { useEffect } from "react";
import { Button } from "../ui/button.jsx";
import { X, Plus, Minus, Heart } from "lucide-react";
function ShoppingCartSidebar({ showCart, setShowCart, cartItems, updateQuantity, removeFromCart, getTotalPrice }) {
  useEffect(() => {
    if (showCart) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [showCart]);
  if (!showCart) return null;
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-black/70 backdrop-blur-sm z-50 animate-fade-in", children: /* @__PURE__ */ jsxDEV("div", { className: "fixed right-0 top-0 h-full w-full max-w-md bg-white shadow-2xl overflow-y-auto transform animate-slide-in-right", children: /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-gray-900", children: "Shopping Cart" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 24,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "ghost",
          onClick: () => setShowCart(false),
          className: "text-gray-500 hover:text-gray-700",
          "aria-label": "Close cart",
          children: /* @__PURE__ */ jsxDEV(X, { className: "w-6 h-6" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 31,
            columnNumber: 15
          }, this)
        },
        void 0,
        false,
        {
          fileName: "<stdin>",
          lineNumber: 25,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 23,
      columnNumber: 11
    }, this),
    cartItems.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-12", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-24 h-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Heart, { className: "w-12 h-12 text-gray-400" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 38,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 37,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-lg", children: "Your cart is empty" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 40,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-gray-400 text-sm mt-2", children: "Add some legendary items to get started" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 41,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 36,
      columnNumber: 13
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 mb-6 max-h-96 overflow-y-auto", children: cartItems.map((item) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-4 bg-gray-50 p-4 rounded-xl border border-gray-200", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV("h4", { className: "font-medium text-gray-900", children: item.name }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 49,
            columnNumber: 23
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-orange-600 font-bold", children: [
            "$",
            item.price
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 50,
            columnNumber: 23
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 48,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-2", children: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "sm",
              variant: "outline",
              onClick: () => updateQuantity(item.id, -1),
              className: "w-8 h-8 rounded-full",
              "aria-label": `Decrease quantity of ${item.name}`,
              children: /* @__PURE__ */ jsxDEV(Minus, { className: "w-3 h-3" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 60,
                columnNumber: 25
              }, this)
            },
            void 0,
            false,
            {
              fileName: "<stdin>",
              lineNumber: 53,
              columnNumber: 23
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "w-8 text-center font-semibold", children: item.quantity }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 62,
            columnNumber: 23
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "sm",
              variant: "outline",
              onClick: () => updateQuantity(item.id, 1),
              className: "w-8 h-8 rounded-full",
              "aria-label": `Increase quantity of ${item.name}`,
              children: /* @__PURE__ */ jsxDEV(Plus, { className: "w-3 h-3" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 70,
                columnNumber: 25
              }, this)
            },
            void 0,
            false,
            {
              fileName: "<stdin>",
              lineNumber: 63,
              columnNumber: 23
            },
            this
          )
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 52,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            size: "sm",
            variant: "ghost",
            onClick: () => removeFromCart(item.id),
            className: "text-red-500 hover:text-red-700 hover:bg-red-50",
            "aria-label": `Remove ${item.name} from cart`,
            children: /* @__PURE__ */ jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 80,
              columnNumber: 23
            }, this)
          },
          void 0,
          false,
          {
            fileName: "<stdin>",
            lineNumber: 73,
            columnNumber: 21
          },
          this
        )
      ] }, item.id, true, {
        fileName: "<stdin>",
        lineNumber: 47,
        columnNumber: 19
      }, this)) }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 45,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "border-t border-gray-200 pt-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-gray-900", children: "Total:" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 88,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-extrabold text-orange-600", children: [
            "$",
            getTotalPrice().toFixed(2)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 89,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 87,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { className: "w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white py-3 font-bold text-lg transform hover:scale-105 transition-all duration-200", children: "Proceed to Checkout" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 91,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 86,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 44,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 22,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 21,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 20,
    columnNumber: 5
  }, this);
}
export {
  ShoppingCartSidebar
};
