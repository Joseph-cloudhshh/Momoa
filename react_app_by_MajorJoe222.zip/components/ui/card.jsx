import { jsxDEV } from "react/jsx-dev-runtime";
import React from "react";
function Card({ className, ...props }) {
  return /* @__PURE__ */ jsxDEV("div", { className: `rounded-xl border bg-card text-card-foreground shadow ${className}`, ...props }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 5,
    columnNumber: 5
  }, this);
}
function CardHeader({ className, ...props }) {
  return /* @__PURE__ */ jsxDEV("div", { className: `flex flex-col space-y-1.5 p-6 ${className}`, ...props }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 11,
    columnNumber: 5
  }, this);
}
function CardTitle({ className, ...props }) {
  return /* @__PURE__ */ jsxDEV("h3", { className: `font-semibold leading-none tracking-tight ${className}`, ...props }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 17,
    columnNumber: 5
  }, this);
}
function CardDescription({ className, ...props }) {
  return /* @__PURE__ */ jsxDEV("p", { className: `text-sm text-muted-foreground ${className}`, ...props }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 23,
    columnNumber: 5
  }, this);
}
function CardContent({ className, ...props }) {
  return /* @__PURE__ */ jsxDEV("div", { className: `p-6 pt-0 ${className}`, ...props }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 29,
    columnNumber: 5
  }, this);
}
function CardFooter({ className, ...props }) {
  return /* @__PURE__ */ jsxDEV("div", { className: `flex items-center p-6 pt-0 ${className}`, ...props }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 35,
    columnNumber: 5
  }, this);
}
export {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
};
