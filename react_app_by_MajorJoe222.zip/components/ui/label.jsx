import { jsxDEV } from "react/jsx-dev-runtime";
import React from "react";
function Label({ className, ...props }) {
  return /* @__PURE__ */ jsxDEV(
    "label",
    {
      className: `text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 ${className}`,
      ...props
    },
    void 0,
    false,
    {
      fileName: "<stdin>",
      lineNumber: 5,
      columnNumber: 5
    },
    this
  );
}
export {
  Label
};
